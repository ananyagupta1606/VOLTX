import ProductCard from "./ProductCard";

export default function ProductGrid({ products, search, category, onAddToCart, onViewDetail }) {
  return (
    <section className="bg-gray-900 min-h-[60vh] px-4 sm:px-6 py-8">
      <div className="max-w-7xl mx-auto">

        {/* Section header */}
        <div className="flex justify-between items-baseline mb-6">
          <h2 className="text-white font-extrabold text-2xl tracking-tight">
            {category === "All" ? "All Products" : category}
          </h2>
          <span className="text-gray-500 text-sm">
            {products.length} item{products.length !== 1 ? "s" : ""}
          </span>
        </div>

        {/* Empty state */}
        {products.length === 0 ? (
          <div className="text-center py-24 text-gray-500">
            <div className="text-5xl mb-4">🔍</div>
            <p className="text-lg font-semibold text-gray-400 mb-1">No results found</p>
            <p className="text-sm">No products matched "{search}"</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {products.map(p => (
              <ProductCard
                key={p.id}
                product={p}
                onAddToCart={onAddToCart}
                onViewDetail={onViewDetail}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
