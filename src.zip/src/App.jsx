import { useState, useRef } from "react";
import { PRODUCTS } from "./data/products";

import Navbar        from "./components/Navbar";
import HeroBanner    from "./components/HeroBanner";
import CategoryBar   from "./components/CategoryBar";
import ProductGrid   from "./components/ProductGrid";
import CartSidebar   from "./components/CartSidebar";
import AuthModal     from "./components/AuthModal";
import ProductDetail from "./components/ProductDetail";
import Toast         from "./components/Toast";
import Footer        from "./components/Footer";

export default function App() {
  // State
  const [search,    setSearch]    = useState("");
  const [category,  setCategory]  = useState("All");
  const [cart,      setCart]      = useState([]);
  const [cartOpen,  setCartOpen]  = useState(false);
  const [authOpen,  setAuthOpen]  = useState(false);
  const [detail,    setDetail]    = useState(null);
  const [user,      setUser]      = useState(null);
  const [notif,     setNotif]     = useState(null);
  const toastTimer = useRef(null);

  // Toast helper
  const toast = (msg, icon = "✅") => {
    setNotif({ msg, icon });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setNotif(null), 2600);
  };

  // Cart helpers
  const addToCart = (product, e) => {
    e?.stopPropagation();
    setCart(prev => {
      const existing = prev.find(i => i.id === product.id);
      return existing
        ? prev.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i)
        : [...prev, { ...product, qty: 1 }];
    });
    toast(`${product.name} added to cart`, "🛒");
  };

  const updateQty = (id, delta) =>
    setCart(prev =>
      prev
        .map(i => i.id === id ? { ...i, qty: Math.max(0, i.qty + delta) } : i)
        .filter(i => i.qty > 0)
    );

  // Auth helpers
  const handleAuth = (userData) => {
    setUser(userData);
    setAuthOpen(false);
    toast(`Welcome, ${userData.name}!`, "⚡");
  };

  const handleSignOut = () => {
    setUser(null);
    toast("Signed out successfully", "👋");
  };

  // Filtered products
  const filteredProducts = PRODUCTS.filter(p => {
    const matchCat    = category === "All" || p.cat === category;
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase())
                     || p.brand.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const cartCount = cart.reduce((a, i) => a + i.qty, 0);

  const scrollToProducts = () =>
    document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });

  return (
    <div className="min-h-screen bg-gray-950 text-gray-200">

      {/* ── Navbar ── */}
      <Navbar
        search={search}
        onSearchChange={setSearch}
        cartCount={cartCount}
        onCartOpen={() => setCartOpen(true)}
        onAuthOpen={() => setAuthOpen(true)}
        user={user}
        onSignOut={handleSignOut}
      />

      {/* ── Hero Banner ── */}
      <HeroBanner onShopNow={scrollToProducts} />

      {/* ── Category Bar ── */}
      <CategoryBar active={category} onChange={setCategory} />

      {/* ── Product Grid ── */}
      <div id="products">
        <ProductGrid
          products={filteredProducts}
          search={search}
          category={category}
          onAddToCart={addToCart}
          onViewDetail={setDetail}
        />
      </div>

      {/* ── Footer ── */}
      <Footer />

      {/* ── Overlays ── */}
      {cartOpen && (
        <CartSidebar
          cart={cart}
          onClose={() => setCartOpen(false)}
          onUpdateQty={updateQty}
          onCheckout={() => { toast("Redirecting to checkout…", "💳"); setCartOpen(false); }}
        />
      )}

      {authOpen && (
        <AuthModal
          onClose={() => setAuthOpen(false)}
          onAuth={handleAuth}
        />
      )}

      {detail && (
        <ProductDetail
          product={detail}
          onClose={() => setDetail(null)}
          onAddToCart={addToCart}
        />
      )}

      {/* ── Toast ── */}
      <Toast message={notif?.msg} icon={notif?.icon} />
    </div>
  );
}
