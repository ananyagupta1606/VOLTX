export const PRODUCTS = [
  { id: 1,  name: 'MacBook Pro 16" M3 Max',    brand: "Apple",   cat: "Laptops",   emoji: "💻", price: 3499, oldPrice: 3999, badge: "new",  rating: 5, specs: "M3 Max · 48GB RAM · 1TB SSD",         desc: "The most powerful MacBook Pro ever made, with the M3 Max chip for extraordinary performance." },
  { id: 2,  name: "Sony WH-1000XM5",           brand: "Sony",    cat: "Audio",     emoji: "🎧", price: 279,  oldPrice: 349,  badge: "sale", rating: 5, specs: "ANC · 30hr battery · Hi-Res Audio",    desc: "Industry-leading noise cancellation with exceptional sound quality." },
  { id: 3,  name: 'Samsung OLED 65" S95D',     brand: "Samsung", cat: "TVs",       emoji: "📺", price: 2199, oldPrice: null, badge: "hot",  rating: 4, specs: "4K OLED · 144Hz · HDR10+",            desc: "Quantum Dot OLED with perfect blacks and vibrant colors." },
  { id: 4,  name: "iPhone 16 Pro Max",         brand: "Apple",   cat: "Phones",    emoji: "📱", price: 1299, oldPrice: null, badge: "new",  rating: 5, specs: "A18 Pro · 256GB · Titanium",          desc: "The most advanced iPhone ever, with a stunning titanium design." },
  { id: 5,  name: "NVIDIA RTX 5090",           brand: "NVIDIA",  cat: "GPUs",      emoji: "🖥️", price: 1999, oldPrice: null, badge: "hot",  rating: 5, specs: "32GB GDDR7 · PCIe 5.0 · 600W",       desc: "Blackwell architecture. The ultimate GPU for gaming and AI." },
  { id: 6,  name: 'iPad Pro 13" M4',           brand: "Apple",   cat: "Tablets",   emoji: "📋", price: 1299, oldPrice: 1499, badge: "sale", rating: 4, specs: "M4 · 256GB · OLED XDR",              desc: "Impossibly thin with a stunning OLED XDR display." },
  { id: 7,  name: "Dell XPS 15 9530",          brand: "Dell",    cat: "Laptops",   emoji: "💻", price: 1899, oldPrice: 2299, badge: "sale", rating: 4, specs: "i9-13900H · RTX 4070 · 2TB",          desc: "Power and precision in a beautifully designed package." },
  { id: 8,  name: "PlayStation 5 Pro",         brand: "Sony",    cat: "Gaming",    emoji: "🎮", price: 699,  oldPrice: null, badge: "new",  rating: 5, specs: "Custom AMD · 8K · 2TB SSD",          desc: "Play has no limits. The most powerful PlayStation ever." },
  { id: 9,  name: "Samsung Galaxy S25 Ultra",  brand: "Samsung", cat: "Phones",    emoji: "📱", price: 1199, oldPrice: 1399, badge: "sale", rating: 4, specs: "Snapdragon 8 Elite · 512GB · S Pen",  desc: "AI-powered. Built to be extraordinary with the built-in S Pen." },
  { id: 10, name: "LG UltraGear 32GS95UE",    brand: "LG",      cat: "Monitors",  emoji: "🖥️", price: 1299, oldPrice: null, badge: null,   rating: 4, specs: "4K OLED · 240Hz · 0.03ms",           desc: "The world's fastest OLED gaming monitor." },
  { id: 11, name: "Bose QuietComfort Ultra",   brand: "Bose",    cat: "Audio",     emoji: "🎧", price: 349,  oldPrice: null, badge: null,   rating: 4, specs: "Immersive Audio · ANC · 24hr",        desc: "Unmatched comfort meets Bose's best sound yet." },
  { id: 12, name: "Apple Watch Ultra 2",       brand: "Apple",   cat: "Wearables", emoji: "⌚", price: 799,  oldPrice: null, badge: null,   rating: 5, specs: "Titanium · GPS · 60hr battery",      desc: "The most capable Apple Watch for demanding adventures." },
];

export const CATEGORIES = [
  "All", "Phones", "Laptops", "Audio", "TVs",
  "GPUs", "Tablets", "Gaming", "Monitors", "Wearables",
];

export const BADGE_STYLES = {
  new:  "bg-green-500 text-black",
  sale: "bg-red-500 text-white",
  hot:  "bg-amber-400 text-black",
};
